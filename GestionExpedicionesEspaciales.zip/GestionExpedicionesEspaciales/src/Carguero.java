/**
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionexpedicionesespaciales;

/**
 *
 * @author Juan I Pingitore
 */
public abstract class Carguero extends Nave {
    private int capacidadCarga; //entre 100 y 500

    public Carguero(String nombre, int anioSalida, int capacidadTripulacion) {
        super(nombre, anioSalida, capacidadTripulacion);
        if(capacidadCarga < 100) capacidadCarga = 100;
        if(capacidadCarga > 500) capacidadCarga = 500;
        this.capacidadCarga = capacidadCarga;
    }
    
    @Override
    public void iniciarMision(){
        System.out.println(nombre + "es un carguero y no participa en la mision de exploracion");
    }
    @Override 
    public String toString(){
    return super.toString() + " | Carga: " +capacidadCarga+ "tn";
    }
}
