/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionexpedicionesespaciales;

/**
 *
 * @author Juan I Pingitore
 */
public abstract class NaveExploracion extends Nave {
    private String tipoMision; //CARTOGRAFIA, INVESTIGACION, CONTACTO   
    
    public NaveExploracion(String nombre, int capacidadTripulacion, int anioSalida, String tipoMision){
        super(nombre, capacidadTripulacion, anioSalida);
        this.tipoMision = tipoMision.toUpperCase();
    }
    
    @Override
    public void iniciarMision(){
        System.out.println("Iniciar mision de exploracion" + tipoMision);
    }
    
    @Override
    public String toString(){
        return super.toString() + " | Mision: " + tipoMision;
    }

}