/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionexpedicionesespaciales;

/**
 *
 * @author Juan I Pingitore
 */
public abstract class Nave implements Comparable<Nave> {
    protected String nombre;
    protected int capacidadTripulacion;
    protected int anioSalida;
    
    public Nave(String nombre, int anioSalida, int capacidadTripulacion){
            this.nombre = nombre;
            this.capacidadTripulacion = capacidadTripulacion;
            this.anioSalida = anioSalida;
    }
    
    public abstract void iniciarMision();
    
    public String getNombre(){
    return nombre;
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    public int getAnioSalida() {
        return anioSalida;
    }
    
    @Override
    public boolean equals(Object o){
        if (this == o)
            return true;
        if (!(o instanceof Nave))
            return false;
        Nave otra = (Nave) o;
        return this.nombre.equalsIgnoreCase(otra.nombre) && this.anioSalida == otra.anioSalida;
    }
    
    @Override
    public String toString(){
        return nombre + " | Tripulacion: " +capacidadTripulacion+ " | Año: " + anioSalida;
    }
}
