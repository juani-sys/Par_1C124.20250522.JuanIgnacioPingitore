/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestionexpedicionesespaciales;
import java.util.Scanner;
/**
 *
 * @author Juan I Pingitore
 */
public class Main {
    public static void main(String[] args) {
      GestorNaves gestor = new GestorNaves();
      Scanner sc = new Scanner(System.in);
      int opcion;
      
      do{
          System.out.println("\n--- MENU DE GESTION DE NAVES ---");
          System.out.println("1. Agregar nave de exploracion");
          System.out.println("2. Agregar carguero");
          System.out.println("3. Agregar crucero estelar");
          System.out.println("4. Mostrar todas las naves");
          System.out.println("5. Iniciar mision de exploracion");
          System.out.println("6. Mostrar naves ordenadas por nombre");
          System.out.println("7. Mostrar naves ordenadas por año de salida");
          System.out.println("8. Mostrar naves ordenadas por capacidad de tripulacion");
          System.out.println("0. Salir...");
          System.out.println("Ingrese opcion");
          opcion = sc.nextInt();
          sc.nextLine();
          
          switch (opcion){
              case 1:
                  System.out.print("Nombre: ");
                  String nombre1 = sc.nextLine();
                  System.out.print("Capacidad Tripulacion: ");
                  int capacidad1 = sc.nextInt();
                  System.out.print("Año de salida: ");
                  int anio1 = sc.nextInt();
                  sc.nextLine();
                  System.out.println("Tipo de mision: ");
                  String tipo = sc.nextLine().toUpperCase();
                  gestor.agregarNave(new NaveExploracion(nombre1, capacidad1, anio1, tipo));
                  break;
              case 2: 
                  System.out.print("Nombre: ");
                  String nombre2 = sc.nextLine();
                  System.out.print("Capacidad Tripulacion: ");
                  int capacidad2 = sc.nextInt();
                  System.out.print("Año de salida: ");
                  int anio2 = sc.nextInt();
                  sc.nextLine();
                  System.out.println("Capacidad de carga: ");
                  int carga = sc.nextInt();
                  gestor.agregarNave(new Carguero(nombre2, capacidad2, anio2, carga));
                  break;
              case 3:
                  System.out.print("Nombre: ");
                  String nombre3 = sc.nextLine();
                  System.out.print("Capacidad Tripulacion: ");
                  int capacidad3 = sc.nextInt();
                  System.out.print("Año de salida: ");
                  int anio3 = sc.nextInt();
                  sc.nextLine();
                  System.out.println("Cantidad de pasajeros: ");
                  int pasajeros = sc.nextInt();
                  gestor.agregarNave(new CruceroEstelar(nombre3, capacidad3, anio3, pasajeros));
                  break;
              case 4: 
                  System.out.println("\n--- LISTADO DE NAVES ---");
                  gestor.mostrarNaves();
                  break;
              case 5:
                  System.out.println("\n--- INICIO DE MISION DE EXPLORACION ---");
                  gestor.iniciarExploracion();
                  break;
              case 6: System.out.println("\n--- NAVES ORDENADAS POR AÑO---");
                  gestor.naves.sort(null);
                  gestor.mostrarOrdenadas();
                  break;
              case 7:
                  System.out.println("\n--- NAVES ORDENADAS POR NOMBRE ---");
                  gestor.ordenarPorNombre();
                  gestor.mostrarOrdenadas();
                  break;
              case 8: 
                  System.out.println("\n--- NAVES ORDENADAS POR TRIPULACION ---");
                  gestor.ordenarPorTripulaciones();
                  gestor.mostrarOrdenadas();
                  break;
              case 0:
                  System.out.println("Saliendo del sistema...");
                  break;
              default:
                  System.out.println("Opcion invalida");
            }
        } while (opcion != 0);
      
        sc.close();
    }    
}
