/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionexpedicionesespaciales;

/**
 *
 * @author Juan I Pingitore
 */
public abstract class CruceroEstelar extends Nave {
    private int cantidadPasajeros;

    public CruceroEstelar(String nombre, int anioSalida, int capacidadTripulacion) {
        super(nombre, anioSalida, capacidadTripulacion);
        this.cantidadPasajeros = cantidadPasajeros;
    }
    
    @Override
    public void iniciarMision(){
        System.out.println(" no participa en la mision de exploracion ");
    }
    
    @Override 
    public String toString(){
        return super.toString() + " | Pasajeros: " + cantidadPasajeros;
    }

}
