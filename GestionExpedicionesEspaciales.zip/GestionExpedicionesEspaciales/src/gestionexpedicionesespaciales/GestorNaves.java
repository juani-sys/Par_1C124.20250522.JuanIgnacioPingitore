/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionexpedicionesespaciales;
import java.util.*;

/**
 *
 * @author Juan I Pingitore
 */
public class GestorNaves {
    List<Nave> naves = new ArrayList<>();
    
    public void agregarNave(Nave nave){
        if(!naves.contains(nave)){
            naves.add(nave);
            System.out.println("Nave agregada correctamente");
        }else{
            System.out.println("Ya existe una nave con el mismo nombre y año");
        }
    }
    
    public void mostrarNaves(){
        for (Nave n : naves){
            System.out.println(n);
        }
    }
    
    public void iniciarExploracion(){
        for(Nave n : naves){
            if (n instanceof NaveExploracion || n instanceof Carguero){
                n.iniciarMision();
            }else{
                System.out.println(n.getNombre() + "no participa en la mision de exploracion");
            }
        }
    }
    
    public void ordenarPorNombre(){
        naves.sort(Comparator.comparing(Nave::getNombre, String.CASE_INSENSITIVE_ORDER));
    }
    
    public void ordenarPorTripulaciones(){
        naves.sort(Comparator.comparing(Nave::getCapacidadTripulacion).reversed());
    }
    
    public void mostrarOrdenadas(){
        for (Nave n : naves){
            System.out.println(n);
        }
    }

    void agregarNave(NaveExploracion naveExploracion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
